package Service;

import java.util.List;
import java.util.stream.Collectors;

import data.BookDTO;
import data.BooksDAO;

public class SearchAdventureBook implements SearchBook {

	@Override
	public void searchBook() {
		BooksDAO book=new BooksDAO();
		book.addInList();
		
		List<BookDTO> data=book.getList().stream().filter(x->x.getCatagory()=="Adventure").collect(Collectors.toList());
		for(BookDTO d:data){
			System.out.println("id: "+d.getBookId()+", name: "+d.getBookName()+", Author: "+", catagory: "+d.getCatagory()+", price:"+d.getPrice());
		}		
	}

}
