package Service;
@FunctionalInterface
public interface SearchBook {
	void searchBook();
}
