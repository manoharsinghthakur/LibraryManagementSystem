package Service;

import java.util.List;
import java.util.stream.Collectors;

import data.BooksDAO;
import data.BookDTO;

public class SearchHorrorBook implements SearchBook{

	@Override
	public void searchBook() {
		BooksDAO book=new BooksDAO();
		book.addInList();
		
		List<BookDTO> data=book.getList().stream().filter(x->x.getCatagory()=="Horror").collect(Collectors.toList());
		for(BookDTO d:data){
			System.out.println("id: "+d.getBookId()+", name: "+d.getBookName()+", Author: "+", catagory: "+d.getCatagory()+", price:"+d.getPrice());
		}
	}

}
