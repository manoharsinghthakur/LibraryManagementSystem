package controller;

public class Starter {
	
	public static void main(String[] args) {
		SearchBookController.searchBook();
	}

}
